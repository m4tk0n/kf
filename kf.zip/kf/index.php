<?php
declare(strict_types=1);

require __DIR__ . '/src/bootstrap.php';

$base  = rtrim((string)parse_url(cfg('app.base_url'), PHP_URL_PATH), '/');
$uri   = (string)parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$path  = trim(substr($uri, strlen($base)), '/');
$parts = $path === '' ? [] : explode('/', $path);
$langs = cfg('app.languages');

// Bez jazyka v URL: přesměrování podle prohlížeče, jinak výchozí jazyk
if (!$parts || !in_array($parts[0], $langs, true)) {
    $accept = strtolower(substr((string)($_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? ''), 0, 2));
    $lang   = in_array($accept, $langs, true) ? $accept : cfg('app.default_lang');
    header('Location: ' . rtrim(cfg('app.base_url'), '/') . '/' . $lang . '/' . $path, true, 302);
    exit;
}

lang_code($parts[0]);
$route = array_slice($parts, 1);
$GLOBALS['KF_ROUTE'] = implode('/', $route);

match ($route[0] ?? '') {
    ''      => page('home'),
    default => page('404', ['title' => L('err-404')], 404),
};
