<?php
declare(strict_types=1);

// ---------- .env a config ----------
function load_env(string $file): void
{
    if (!is_file($file)) {
        throw new RuntimeException('.env not found');
    }
    foreach (file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [] as $line) {
        $line = trim($line);
        if ($line === '' || $line[0] === '#' || !str_contains($line, '=')) {
            continue;
        }
        [$k, $v] = explode('=', $line, 2);
        $v = trim($v);
        if (strlen($v) >= 2 && ($v[0] === '"' || $v[0] === "'") && $v[-1] === $v[0]) {
            $v = substr($v, 1, -1);
        }
        $GLOBALS['KF_ENV'][trim($k)] = $v;
    }
}

function env(string $key): string
{
    if (!isset($GLOBALS['KF_ENV'][$key])) {
        throw new RuntimeException("Missing .env key: $key");
    }
    return $GLOBALS['KF_ENV'][$key];
}

function cfg(string $key): mixed
{
    $v = $GLOBALS['KF_CFG'];
    foreach (explode('.', $key) as $part) {
        if (!is_array($v) || !array_key_exists($part, $v)) {
            throw new RuntimeException("Missing config key: $key");
        }
        $v = $v[$part];
    }
    return $v;
}

function path(string $dir, string $sub = ''): string
{
    return KF_ROOT . '/' . cfg("paths.$dir") . ($sub !== '' ? '/' . ltrim($sub, '/') : '');
}

// ---------- databáze ----------
function tbl(string $name): string
{
    return '`' . cfg('db.prefix') . preg_replace('/[^a-z_]/', '', $name) . '`';
}

function db(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        $dsn = 'mysql:host=' . cfg('db.host') . ';dbname=' . cfg('db.name') . ';charset=' . cfg('db.charset');
        $pdo = new PDO($dsn, cfg('db.user'), cfg('db.pass'), [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]);
    }
    return $pdo;
}

// ---------- text ----------
function e(mixed $s): string
{
    return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function slugify(string $s): string
{
    static $map = [
        'á'=>'a','ä'=>'a','à'=>'a','â'=>'a','å'=>'a','ą'=>'a','ã'=>'a','æ'=>'ae',
        'č'=>'c','ć'=>'c','ç'=>'c','ď'=>'d','é'=>'e','ě'=>'e','è'=>'e','ê'=>'e','ë'=>'e','ę'=>'e',
        'í'=>'i','ï'=>'i','î'=>'i','ł'=>'l','ľ'=>'l','ĺ'=>'l','ň'=>'n','ń'=>'n','ñ'=>'n',
        'ó'=>'o','ö'=>'o','ô'=>'o','ő'=>'o','ø'=>'o','õ'=>'o','œ'=>'oe',
        'ř'=>'r','š'=>'s','ś'=>'s','ß'=>'ss','ť'=>'t','ú'=>'u','ů'=>'u','ü'=>'u','ű'=>'u','û'=>'u',
        'ý'=>'y','ÿ'=>'y','ž'=>'z','ź'=>'z','ż'=>'z',
    ];
    $s = strtr(mb_strtolower($s, 'UTF-8'), $map);
    return trim((string)preg_replace('/[^a-z0-9]+/', '-', $s), '-');
}

// ---------- jazyky ----------
function lang_code(?string $set = null): string
{
    static $lang = null;
    if ($set !== null) {
        $lang = $set;
    }
    return $lang ?? cfg('app.default_lang');
}

function lang_groups(?string $add = null): array
{
    static $g = ['common' => true];
    if ($add !== null) {
        $g[$add] = true;
    }
    return array_keys($g);
}

function lang_load(string $group): void
{
    lang_groups($group);
}

function lang_map(string $lang): array
{
    static $cache = [];
    $groups = lang_groups();
    $ck = $lang . '|' . implode(',', $groups);
    if (!isset($cache[$ck])) {
        $map = [];
        foreach ($groups as $g) {
            $f = path('lang', "$lang/$g.ini");
            if (is_file($f)) {
                $map += parse_ini_file($f) ?: [];
            }
        }
        $cache[$ck] = $map;
    }
    return $cache[$ck];
}

// Překlad za běhu; chybějící klíč v aktuálním jazyce se doplní z výchozího
function L(string $key, array $params = []): string
{
    $s = lang_map(lang_code())[$key] ?? lang_map(cfg('app.default_lang'))[$key] ?? $key;
    foreach ($params as $k => $v) {
        $s = str_replace('{' . $k . '}', (string)$v, $s);
    }
    return $s;
}

// Množné číslo: klíče key-one / key-few / key-many
function Ln(string $key, int $n): string
{
    $form = cfg('plural.' . lang_code())($n);
    return L("$key-$form", ['n' => $n]);
}

function url(string $path = '', ?string $lang = null): string
{
    return rtrim(cfg('app.base_url'), '/') . '/' . ($lang ?? lang_code()) . '/' . ltrim($path, '/');
}

// ---------- šablony ----------
// Klíče [btn-back] se nahradí při kompilaci šablony (ne ve výstupu), takže data z DB
// se nikdy nepřekládají. Zkompilovaná šablona se kešuje po jazycích.
function view(string $name, array $vars = []): string
{
    $lang  = lang_code();
    $def   = cfg('app.default_lang');
    $src   = path('templates', "$name.php");
    $dst   = path('cache', 'tpl/' . $lang . '/' . str_replace('/', '_', $name) . '.php');
    $files = array_merge(
        [$src],
        glob(path('lang', "$lang/*.ini")) ?: [],
        glob(path('lang', "$def/*.ini")) ?: []
    );
    $newest = max(array_map('filemtime', $files));

    if (!is_file($dst) || filemtime($dst) < $newest) {
        $map = [];
        foreach (lang_map($lang) + lang_map($def) as $k => $v) {
            $map['[' . $k . ']'] = e($v);
        }
        @mkdir(dirname($dst), 0755, true);
        file_put_contents($dst, strtr((string)file_get_contents($src), $map), LOCK_EX);
    }

    extract($vars, EXTR_SKIP);
    ob_start();
    include $dst;
    return (string)ob_get_clean();
}

// Celá stránka, nebo jen obsah, když ho JavaScript žádá hlavičkou X-Partial
function page(string $tpl, array $vars = [], int $status = 200): void
{
    http_response_code($status);
    $title   = (string)($vars['title'] ?? L('site-name'));
    $content = view($tpl, $vars);
    header('Vary: X-Partial');
    if (($_SERVER['HTTP_X_PARTIAL'] ?? '') === '1') {
        header('X-Title: ' . rawurlencode($title));
        echo $content;
        return;
    }
    echo view('layout', ['content' => $content, 'title' => $title]);
}
